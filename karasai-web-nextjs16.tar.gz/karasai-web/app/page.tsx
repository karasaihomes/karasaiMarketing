import Link from 'next/link'
import Image from 'next/image'
import { Play } from 'lucide-react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section with Background Image */}
        <section className="relative h-[500px] bg-karasai-blue">
          <div className="absolute inset-0">
            <Image
              src="https://placehold.co/1920x500/4E70C6/FFF?text=Suburban+Houses"
              alt="Suburban houses"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-b from-karasai-blue/40 to-transparent" />
          </div>
          
          <div className="container-custom relative z-10 flex h-full flex-col items-center justify-center text-center text-white">
            <h1 className="mb-4 text-4xl font-bold uppercase tracking-wide md:text-5xl">
              Verify Your Rental Home in Seconds
            </h1>
            <p className="mb-8 text-lg md:text-xl">
              We make it simple to find verified rental homes
            </p>
            
            {/* Search Box */}
            <div className="w-full max-w-2xl">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter city, state, or ZIP code"
                  className="flex-1 rounded-md px-6 py-4 text-neutral-dark placeholder:text-neutral-dark/50 focus:outline-none focus:ring-2 focus:ring-karasai-blue"
                />
                <Link
                  href="/search"
                  className="rounded-md bg-karasai-blue px-8 py-4 font-semibold uppercase tracking-wide text-white transition-colors hover:bg-karasai-blue/90"
                >
                  Search
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Properties Section */}
        <section className="bg-white py-16">
          <div className="container-custom">
            <h2 className="mb-12 text-center text-2xl font-medium text-karasai-blue">
              Here are some homes we think you'll love.
            </h2>
            
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {/* Property Card 1 */}
              <Link href="/properties/1" className="group">
                <div className="overflow-hidden rounded-lg shadow-md transition-shadow hover:shadow-lg">
                  <div className="relative h-48">
                    <Image
                      src="https://placehold.co/400x300/BFDBF7/333?text=Charlotte+Home"
                      alt="Charlotte, NC home"
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="bg-white p-4 text-center">
                    <p className="text-sm font-medium uppercase tracking-wider text-neutral-dark">
                      Charlotte, NC
                    </p>
                  </div>
                </div>
              </Link>

              {/* Property Card 2 */}
              <Link href="/properties/2" className="group">
                <div className="overflow-hidden rounded-lg shadow-md transition-shadow hover:shadow-lg">
                  <div className="relative h-48">
                    <Image
                      src="https://placehold.co/400x300/BFDBF7/333?text=Odessa+Home"
                      alt="Odessa, TX home"
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="bg-white p-4 text-center">
                    <p className="text-sm font-medium uppercase tracking-wider text-neutral-dark">
                      Odessa, TX
                    </p>
                  </div>
                </div>
              </Link>

              {/* Property Card 3 */}
              <Link href="/properties/3" className="group">
                <div className="overflow-hidden rounded-lg shadow-md transition-shadow hover:shadow-lg">
                  <div className="relative h-48">
                    <Image
                      src="https://placehold.co/400x300/BFDBF7/333?text=Tulsa+Home"
                      alt="Tulsa, OK home"
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="bg-white p-4 text-center">
                    <p className="text-sm font-medium uppercase tracking-wider text-neutral-dark">
                      Tulsa, OK
                    </p>
                  </div>
                </div>
              </Link>

              {/* Property Card 4 */}
              <Link href="/properties/4" className="group">
                <div className="overflow-hidden rounded-lg shadow-md transition-shadow hover:shadow-lg">
                  <div className="relative h-48">
                    <Image
                      src="https://placehold.co/400x300/BFDBF7/333?text=Atlanta+Home"
                      alt="Atlanta, GA home"
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="bg-white p-4 text-center">
                    <p className="text-sm font-medium uppercase tracking-wider text-neutral-dark">
                      Atlanta, GA
                    </p>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* Video Testimonial Section */}
        <section className="bg-gradient-to-b from-karasai-light/30 to-karasai-light py-16">
          <div className="container-custom">
            <div className="mx-auto max-w-4xl">
              <div className="relative aspect-video overflow-hidden rounded-lg shadow-xl">
                <Image
                  src="https://placehold.co/1200x675/4E70C6/FFF?text=Video+Testimonial"
                  alt="Video testimonial"
                  fill
                  className="object-cover"
                />
                <button className="absolute inset-0 flex items-center justify-center bg-neutral-dark/20 transition-colors hover:bg-neutral-dark/30">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/90 shadow-lg transition-transform hover:scale-110">
                    <Play className="h-8 w-8 fill-karasai-blue text-karasai-blue" />
                  </div>
                </button>
              </div>
              <p className="mt-8 text-center text-neutral-dark/70">
                We've partnered with some of the industries largest owners and operators of rental homes. 
                Listen to how VERIHOME is changing the way people find and verify their new rental home.
              </p>
            </div>
          </div>
        </section>

        {/* How Karasai Works Section */}
        <section className="bg-white py-16">
          <div className="container-custom">
            <h2 className="mb-8 text-center text-3xl font-bold uppercase tracking-wide text-neutral-dark">
              How Karasai Works
            </h2>
            
            <div className="mx-auto max-w-4xl space-y-6 text-neutral-dark/80">
              <p>
                We hate hearing about people who have their hard earned money taken by unscrupulous people. 
                So we created KARASAI, a verification service that exists to ensure you are dealing directly 
                with the owner or landlord of a rental property.
              </p>
              
              <p>
                We've done the hard work for you, and verified every single home in our database of rental 
                properties that covers the entire United States. Each home listed on KARASAI is actually 
                owned or operated by the stated landlord and ensure their contact information is current.
              </p>
              
              <p>
                Once we've verified a home is a legitimate rental home, it's added to our searchable database 
                to allow you to not only find a home, but also double check to ensure the person you're speaking 
                with is the actual owner or operator of the home. We guarantee it.
              </p>
              
              <p>
                Many of the homes listed are owned and operated by corporate entities, so you may be dealing 
                with a group of people who represent that organization, but rest assured you are dealing with 
                the legitimate owner and operator of that home.
              </p>
            </div>
          </div>
        </section>

        {/* Bottom CTA Cards */}
        <section className="bg-neutral-gray py-16">
          <div className="container-custom">
            <div className="grid gap-8 md:grid-cols-3">
              {/* First Time Renter Card */}
              <div className="overflow-hidden rounded-lg shadow-md">
                <div className="relative h-48">
                  <Image
                    src="https://placehold.co/600x400/BFDBF7/333?text=First+Time+Renter"
                    alt="First time renter"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="bg-karasai-blue p-6 text-center">
                  <p className="font-semibold uppercase tracking-wide text-white">
                    First Time Renter?
                  </p>
                </div>
              </div>

              {/* About Us Card */}
              <div className="overflow-hidden rounded-lg shadow-md">
                <div className="relative h-48">
                  <Image
                    src="https://placehold.co/600x400/BFDBF7/333?text=About+Us"
                    alt="About us"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="bg-karasai-blue p-6 text-center">
                  <p className="font-semibold uppercase tracking-wide text-white">About Us</p>
                </div>
              </div>

              {/* Karasai Guarantee Card */}
              <div className="overflow-hidden rounded-lg shadow-md">
                <div className="relative h-48">
                  <Image
                    src="https://placehold.co/600x400/BFDBF7/333?text=Karasai+Guarantee"
                    alt="Karasai guarantee"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="bg-karasai-blue p-6 text-center">
                  <p className="font-semibold uppercase tracking-wide text-white">
                    Karasai Guarantee
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
