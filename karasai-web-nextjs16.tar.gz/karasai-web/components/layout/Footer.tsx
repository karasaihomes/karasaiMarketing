import Link from 'next/link'

export default function Footer() {
  const companyLinks = [
    { name: 'KARASAI', href: '/' },
    { name: 'VERIFY A RENTAL HOME', href: '/search' },
    { name: 'LIST YOUR HOME WITH US', href: '/list-your-home' },
  ]

  const aboutLinks = [
    { name: 'ABOUT US', href: '/about' },
    { name: 'BLOG', href: '/articles' },
    { name: 'PRIVACY POLICY', href: '/privacy' },
    { name: 'TERMS OF SERVICE', href: '/terms' },
  ]

  const helpLinks = [
    { name: 'HELP CENTER', href: '/help' },
    { name: 'GET STARTED', href: '/search' },
    { name: 'CONTACT US', href: '/contact' },
    { name: 'FAQ', href: '/faq' },
  ]

  const connectLinks = [
    { name: 'INSTAGRAM', href: '#' },
    { name: 'FACEBOOK', href: '#' },
    { name: 'LINKEDIN', href: '#' },
  ]

  return (
    <footer className="border-t border-white/20 bg-karasai-blue text-white">
      <div className="container-custom py-12 md:py-16">
        {/* Divider */}
        <div className="mb-8 border-t border-white/20" />

        {/* Footer Links */}
        <div className="grid gap-8 md:grid-cols-4">
          {/* Company */}
          <div>
            <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider">
              Company
            </h3>
            <ul className="space-y-3">
              {companyLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-xs uppercase tracking-wide text-white/90 transition-colors hover:text-white"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* About */}
          <div>
            <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider">
              About
            </h3>
            <ul className="space-y-3">
              {aboutLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-xs uppercase tracking-wide text-white/90 transition-colors hover:text-white"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider">
              Help
            </h3>
            <ul className="space-y-3">
              {helpLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-xs uppercase tracking-wide text-white/90 transition-colors hover:text-white"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h3 className="mb-4 text-xs font-semibold uppercase tracking-wider">
              Connect
            </h3>
            <ul className="space-y-3">
              {connectLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-xs uppercase tracking-wide text-white/90 transition-colors hover:text-white"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </footer>
  )
}
